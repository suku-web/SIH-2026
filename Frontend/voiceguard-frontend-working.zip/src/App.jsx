import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import VoiceRecorder from './components/VoiceRecorder.jsx';
import { API_BASE_URL, analyzeCall, checkHealth, enrollVoice } from './lib/api.js';
import './App.css';

const NA = () => <span className="na">N/A</span>;

function clientSessionId() {
  const key = 'voiceguard_client_session_id';
  let id = window.sessionStorage.getItem(key);
  if (!id) {
    id = 'CLIENT-' + Math.random().toString(16).slice(2, 10).toUpperCase();
    window.sessionStorage.setItem(key, id);
  }
  return id;
}

export default function App() {
  // ---- system / connection state (real, derived from actual /health calls) ----
  const [health, setHealth] = useState({ checked: false, ok: false, latencyMs: null, error: null, lastChecked: null });
  const [online, setOnline] = useState(navigator.onLine);
  const sessionId = useMemo(() => clientSessionId(), []);

  // ---- request monitor: real request/response telemetry, not fabricated ----
  const [requestLog, setRequestLog] = useState([]);
  const logRequest = useCallback((entry) => {
    setRequestLog((prev) => [{ ...entry, id: Date.now() + Math.random() }, ...prev].slice(0, 25));
  }, []);

  // ---- enrollment ----
  const [enrollIdentity, setEnrollIdentity] = useState('');
  const [enrollBlob, setEnrollBlob] = useState(null);
  const [enrollState, setEnrollState] = useState({ loading: false, result: null, error: null });

  // ---- analysis ----
  const [claimedIdentity, setClaimedIdentity] = useState('');
  const [analyzeBlob, setAnalyzeBlob] = useState(null);
  const [analyzeState, setAnalyzeState] = useState({ loading: false, result: null, error: null, timestamp: null, filename: null });

  const [transcriptSearch, setTranscriptSearch] = useState('');
  const [rawExpanded, setRawExpanded] = useState(false);
  const [copyLabel, setCopyLabel] = useState('COPY JSON');

  // ---- health polling ----
  const pollHealth = useCallback(async () => {
    const res = await checkHealth();
    logRequest({ method: res.method, endpoint: res.endpoint, status: res.status, requestTimeMs: res.requestTimeMs, ok: res.ok, timestamp: res.timestamp });
    setHealth({
      checked: true,
      ok: res.ok && res.data?.status === 'ok',
      latencyMs: res.requestTimeMs,
      error: res.ok ? null : res.error,
      lastChecked: new Date().toLocaleTimeString(),
    });
  }, [logRequest]);

  useEffect(() => {
    pollHealth();
    const interval = setInterval(pollHealth, 10000);
    const onOnline = () => setOnline(true);
    const onOffline = () => setOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      clearInterval(interval);
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, [pollHealth]);

  // ---- actions ----
  const handleEnroll = async () => {
    if (!enrollIdentity.trim() || !enrollBlob) return;
    setEnrollState({ loading: true, result: null, error: null });
    const res = await enrollVoice(enrollIdentity.trim(), enrollBlob);
    logRequest({ method: res.method, endpoint: res.endpoint, status: res.status, requestTimeMs: res.requestTimeMs, ok: res.ok, timestamp: res.timestamp });
    if (res.ok) {
      setEnrollState({ loading: false, result: res.data, error: null });
    } else {
      setEnrollState({ loading: false, result: null, error: res.error });
    }
  };

  const handleAnalyze = async () => {
    if (!claimedIdentity.trim() || !analyzeBlob) return;
    setAnalyzeState({ loading: true, result: null, error: null, timestamp: null, filename: null });
    const startedAt = new Date();
    const res = await analyzeCall(claimedIdentity.trim(), analyzeBlob);
    logRequest({ method: res.method, endpoint: res.endpoint, status: res.status, requestTimeMs: res.requestTimeMs, ok: res.ok, timestamp: res.timestamp });
    if (res.ok) {
      setAnalyzeState({
        loading: false,
        result: res.data,
        error: null,
        timestamp: startedAt.toLocaleString(),
        filename: 'call.wav',
      });
    } else {
      setAnalyzeState({ loading: false, result: null, error: res.error, timestamp: null, filename: null });
    }
  };

  const result = analyzeState.result;

  const highlightedTranscript = useMemo(() => {
    if (!result?.transcript) return null;
    if (!transcriptSearch.trim()) return result.transcript;
    const term = transcriptSearch.trim();
    const parts = result.transcript.split(new RegExp(`(${term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi'));
    return parts.map((part, i) =>
      part.toLowerCase() === term.toLowerCase() ? (
        <mark key={i}>{part}</mark>
      ) : (
        <span key={i}>{part}</span>
      )
    );
  }, [result, transcriptSearch]);

  const copyTranscript = () => {
    if (result?.transcript) navigator.clipboard.writeText(result.transcript);
  };

  const copyRawJson = () => {
    if (result) {
      navigator.clipboard.writeText(JSON.stringify(result, null, 2));
      setCopyLabel('COPIED');
      setTimeout(() => setCopyLabel('COPY JSON'), 1500);
    }
  };

  const backendOnline = health.checked && health.ok;

  return (
    <div className="vg">
      <div className="vg__scanline" />

      {/* ---------------- HEADER ---------------- */}
      <header className="vg-header">
        <div className="vg-header__brand">
          <span className="vg-header__logo">◈</span>
          <div>
            <h1>VOICEGUARD</h1>
            <p className="vg-header__sub">REAL-TIME VOICE SECURITY &amp; FRAUD DETECTION</p>
          </div>
        </div>

        <div className="vg-header__status">
          <StatusChip label="BACKEND" ok={backendOnline} okText="ONLINE" badText={health.checked ? 'OFFLINE' : 'CHECKING…'} />
          <StatusChip label="API" ok={backendOnline} okText="ONLINE" badText="OFFLINE" />
          <StatusChip label="NETWORK" ok={online} okText="CONNECTED" badText="DISCONNECTED" />
          <div className="vg-header__endpoint">{API_BASE_URL}</div>
        </div>
      </header>

      {health.checked && !backendOnline && (
        <div className="vg-banner vg-banner--error">
          <strong>BACKEND CONNECTION FAILED</strong>
          <span>
            Unable to reach <code>{API_BASE_URL}</code>
            {health.error ? ` — ${health.error}` : ''}. Check that the FastAPI server is running
            (<code>uvicorn api:app --reload --port 8004</code>) and that CORS is configured for this origin.
          </span>
        </div>
      )}

      {/* ---------------- MAIN GRID ---------------- */}
      <main className="vg-grid">
        {/* LEFT COLUMN */}
        <section className="vg-col vg-col--left">
          <Panel title="CALL / SESSION DETAILS">
            <Row label="CLIENT SESSION ID" value={sessionId} mono />
            <Row label="RECORD ID" value={<NA />} note="backend does not return one" />
            <Row label="CLAIMED IDENTITY" value={analyzeState.result?.claimed_identity || <NA />} />
            <Row label="TIMESTAMP" value={analyzeState.timestamp || <NA />} />
            <Row label="AUDIO FILE" value={analyzeState.filename || <NA />} />
            <Row
              label="PROCESSING STATUS"
              value={
                analyzeState.loading
                  ? 'PROCESSING REQUEST…'
                  : analyzeState.result
                  ? 'COMPLETE'
                  : analyzeState.error
                  ? 'FAILED'
                  : 'AWAITING CALL'
              }
            />
          </Panel>

          <Panel title="IDENTITY VERIFICATION">
            {result ? (
              <>
                <Row label="CLAIMED IDENTITY" value={result.claimed_identity ?? <NA />} />
                <Row
                  label="SPEAKER MATCH"
                  value={typeof result.speaker_match_score === 'number' ? `${result.speaker_match_score}%` : <NA />}
                />
                <Row
                  label="IDENTITY"
                  value={
                    <span className={`tag tag--${result.identity_verified ? 'ok' : 'bad'}`}>
                      {result.identity_verified ? 'VERIFIED' : 'NOT VERIFIED'}
                    </span>
                  }
                />
                {result.reason && <Row label="REASON" value={result.reason} />}
              </>
            ) : (
              <EmptyState text="Run ANALYZE CALL to see identity verification results." />
            )}
          </Panel>

          <Panel title="REAL-TIME ANALYSIS">
            <Row label="ANALYSIS STATUS" value={analyzeState.loading ? 'RUNNING' : result ? 'IDLE — LAST RUN COMPLETE' : 'IDLE'} />
            <Row label="AUDIO STREAM" value={<NA />} note="backend exposes no stream metric" />
            <Row label="SAMPLE RATE" value={<NA />} note="not returned by /analyze" />
            <Row label="PROCESSING" value={analyzeState.loading ? 'ACTIVE' : 'STANDBY'} />
            <Row
              label="CONFIDENCE"
              value={typeof result?.speaker_match_score === 'number' ? `${result.speaker_match_score}%` : <NA />}
              note="mapped from speaker_match_score"
            />
          </Panel>
        </section>

        {/* CENTER COLUMN */}
        <section className="vg-col vg-col--center">
          <Panel title="LIVE CALL — ANALYZE" accent>
            <label className="field-label">CLAIMED IDENTITY</label>
            <input
              className="text-input"
              placeholder="e.g. CFO"
              value={claimedIdentity}
              onChange={(e) => setClaimedIdentity(e.target.value)}
              disabled={analyzeState.loading}
            />
            <VoiceRecorder onRecordingReady={setAnalyzeBlob} disabled={analyzeState.loading} />
            <button
              className="btn btn--full btn--primary"
              onClick={handleAnalyze}
              disabled={!claimedIdentity.trim() || !analyzeBlob || analyzeState.loading}
            >
              {analyzeState.loading ? 'ANALYZING…' : 'ANALYZE CALL'}
            </button>
            {analyzeState.error && <div className="voice-recorder__error">{analyzeState.error}</div>}
          </Panel>

          <Panel title="PROCESSING PIPELINE">
            <PipelineFlow active={analyzeState.loading} done={!!result} />
            <p className="vg-note">
              This visualizes the real pipeline in <code>pipeline.py</code>: speaker verification and
              conversation risk analysis. Voice-clone detection, a scored risk engine, fraud prevention,
              and an audit/blockchain record exist as separate modules/folders in the repo (e.g.{' '}
              <code>m3_voice_clone_detection</code>) but are not currently called from{' '}
              <code>combined_analysis()</code>, so this UI does not display values for them.
            </p>
          </Panel>

          <Panel title="VOICE ENROLLMENT">
            <label className="field-label">IDENTITY</label>
            <input
              className="text-input"
              placeholder="e.g. CFO"
              value={enrollIdentity}
              onChange={(e) => setEnrollIdentity(e.target.value)}
              disabled={enrollState.loading}
            />
            <VoiceRecorder onRecordingReady={setEnrollBlob} disabled={enrollState.loading} />
            <button
              className="btn btn--full btn--ghost"
              onClick={handleEnroll}
              disabled={!enrollIdentity.trim() || !enrollBlob || enrollState.loading}
            >
              {enrollState.loading ? 'ENROLLING…' : 'ENROLL VOICE'}
            </button>
            {enrollState.result && (
              <div className="vg-banner vg-banner--ok">
                <strong>ENROLLMENT {String(enrollState.result.status || '').toUpperCase()}</strong>
                <span>{enrollState.result.identity}</span>
              </div>
            )}
            {enrollState.error && <div className="voice-recorder__error">{enrollState.error}</div>}
          </Panel>
        </section>

        {/* RIGHT COLUMN */}
        <section className="vg-col vg-col--right">
          <Panel title="SYSTEM CONNECTION">
            <Row label="CONNECTION" value={<span className={`tag tag--${backendOnline ? 'ok' : 'bad'}`}>{backendOnline ? 'SECURE' : 'OFFLINE'}</span>} />
            <Row label="NETWORK" value={<span className={`tag tag--${online ? 'ok' : 'bad'}`}>{online ? 'CONNECTED' : 'DISCONNECTED'}</span>} />
            <Row label="LATENCY" value={health.latencyMs != null ? `${health.latencyMs}ms` : <NA />} />
            <Row label="API" value={<span className={`tag tag--${backendOnline ? 'ok' : 'bad'}`}>{backendOnline ? 'ONLINE' : 'OFFLINE'}</span>} />
            <Row label="LAST CHECK" value={health.lastChecked || <NA />} />
          </Panel>

          <Panel title="CONVERSATION RISK">
            {result ? (
              <>
                <Row
                  label="RISK SCORE"
                  value={typeof result.conversation_risk_score === 'number' ? result.conversation_risk_score : <NA />}
                  note="0–100, rule-based scorer"
                />
                {result.risk_flags && result.risk_flags.length > 0 ? (
                  <div className="flag-list">
                    {result.risk_flags.map((flag) => (
                      <div key={flag} className="flag-item">
                        <span className="tag tag--warn">{flag.replaceAll('_', ' ').toUpperCase()}</span>
                        {result.matched_phrases?.[flag] && (
                          <span className="flag-phrase">“{result.matched_phrases[flag]}”</span>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="tag tag--ok" style={{ marginTop: 8 }}>
                    NO RISK FLAGS DETECTED
                  </div>
                )}
              </>
            ) : (
              <EmptyState text="Run ANALYZE CALL to see conversation risk results." />
            )}
          </Panel>

          <Panel title="UNWIRED MODULES">
            <p className="vg-note">
              These are referenced in the project brief and exist as folders/plans in the repo, but{' '}
              <code>pipeline.py</code> does not currently call them, so <code>/analyze</code> returns
              nothing for them. Showing a status here rather than fabricated numbers.
            </p>
            <Row label="VOICE CLONE DETECTION" value={<span className="tag tag--idle">NOT WIRED</span>} />
            <Row label="RISK ENGINE (LEVEL/DECISION)" value={<span className="tag tag--idle">NOT WIRED</span>} />
            <Row label="FRAUD PREVENTION ACTION" value={<span className="tag tag--idle">NOT WIRED</span>} />
            <Row label="AUDIT / BLOCKCHAIN RECORD" value={<span className="tag tag--idle">NOT WIRED</span>} />
          </Panel>
        </section>
      </main>

      {/* ---------------- LOWER AREA ---------------- */}
      <section className="vg-lower">
        <Panel title="FULL TRANSCRIPT">
          {result?.transcript ? (
            <>
              <div className="transcript-toolbar">
                <input
                  className="text-input text-input--sm"
                  placeholder="Search transcript…"
                  value={transcriptSearch}
                  onChange={(e) => setTranscriptSearch(e.target.value)}
                />
                <button className="btn btn--ghost btn--sm" onClick={copyTranscript}>
                  COPY TRANSCRIPT
                </button>
              </div>
              <div className="transcript-body">{highlightedTranscript}</div>
            </>
          ) : (
            <EmptyState text="Transcript will appear here after ANALYZE CALL returns a result." />
          )}
        </Panel>

        <Panel title="RAW API RESPONSE">
          {result ? (
            <>
              <div className="transcript-toolbar">
                <button className="btn btn--ghost btn--sm" onClick={() => setRawExpanded((v) => !v)}>
                  {rawExpanded ? 'COLLAPSE' : 'EXPAND'}
                </button>
                <button className="btn btn--ghost btn--sm" onClick={copyRawJson}>
                  {copyLabel}
                </button>
              </div>
              {rawExpanded && <pre className="raw-json">{JSON.stringify(result, null, 2)}</pre>}
            </>
          ) : (
            <EmptyState text="Raw backend JSON will appear here after a successful /analyze call." />
          )}
        </Panel>

        <Panel title="API REQUEST MONITOR">
          {requestLog.length === 0 ? (
            <EmptyState text="No requests sent yet." />
          ) : (
            <table className="req-table">
              <thead>
                <tr>
                  <th>METHOD</th>
                  <th>ENDPOINT</th>
                  <th>STATUS</th>
                  <th>TIME</th>
                </tr>
              </thead>
              <tbody>
                {requestLog.map((r) => (
                  <tr key={r.id}>
                    <td>{r.method}</td>
                    <td>{r.endpoint}</td>
                    <td className={r.ok ? 'req-ok' : 'req-bad'}>{r.status || 'ERR'}</td>
                    <td>{(r.requestTimeMs / 1000).toFixed(2)}s</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Panel>
      </section>

      <footer className="vg-footer">VOICEGUARD · SIH-2026 · SOURCE OF TRUTH: {API_BASE_URL}</footer>
    </div>
  );
}

// ---------------- small presentational components ----------------

function Panel({ title, children, accent }) {
  return (
    <div className={`panel ${accent ? 'panel--accent' : ''}`}>
      <div className="panel__title">{title}</div>
      <div className="panel__body">{children}</div>
    </div>
  );
}

function Row({ label, value, note, mono }) {
  return (
    <div className="row">
      <span className="row__label">{label}</span>
      <span className={`row__value ${mono ? 'mono' : ''}`}>{value}</span>
      {note && <span className="row__note">{note}</span>}
    </div>
  );
}

function StatusChip({ label, ok, okText, badText }) {
  return (
    <div className="status-chip">
      <span className={`status-chip__dot status-chip__dot--${ok ? 'ok' : 'bad'}`} />
      <span className="status-chip__label">{label}</span>
      <span className="status-chip__value">{ok ? okText : badText}</span>
    </div>
  );
}

function EmptyState({ text }) {
  return <div className="empty-state">{text}</div>;
}

function PipelineFlow({ active, done }) {
  const stages = ['AUDIO', 'SPEAKER VERIFICATION', 'TRANSCRIPTION', 'CONVERSATION RISK ANALYSIS'];
  return (
    <div className="pipeline">
      {stages.map((stage, i) => (
        <div key={stage} className="pipeline__stage">
          <span className={`pipeline__dot ${done ? 'pipeline__dot--done' : active ? 'pipeline__dot--active' : ''}`} />
          <span className="pipeline__label">{stage}</span>
          {i < stages.length - 1 && <span className="pipeline__arrow">↓</span>}
        </div>
      ))}
    </div>
  );
}
